"""
Vectorizer Module
Converts geometric primitives to CAD entities
"""

import numpy as np
from typing import List, Tuple, Dict
from dataclasses import dataclass
import logging

from geometry_extractor import GeometricPrimitive, PrimitiveType

logger = logging.getLogger(__name__)


@dataclass
class CADEntity:
    """Represents a CAD entity"""
    entity_type: str  # 'LINE', 'CIRCLE', 'ARC', 'POLYLINE', etc.
    layer: str
    properties: Dict
    
    def __repr__(self):
        return f"CAD {self.entity_type} on layer '{self.layer}'"


class Vectorizer:
    """Converts geometric primitives to CAD entities"""
    
    def __init__(self, 
                 default_layer: str = "0",
                 line_color: int = 7,  # White
                 line_weight: float = 0.25):
        """
        Initialize vectorizer
        
        Args:
            default_layer: Default layer name
            line_color: Default line color (AutoCAD color index)
            line_weight: Default line weight in mm
        """
        self.default_layer = default_layer
        self.line_color = line_color
        self.line_weight = line_weight
        
        logger.info("Vectorizer initialized")
    
    def vectorize(self, primitives: List[GeometricPrimitive]) -> List[CADEntity]:
        """
        Convert geometric primitives to CAD entities
        
        Args:
            primitives: List of geometric primitives
            
        Returns:
            List of CAD entities
        """
        entities = []
        
        for primitive in primitives:
            entity = self._convert_primitive(primitive)
            if entity:
                entities.append(entity)
        
        logger.info(f"Vectorized {len(entities)} entities")
        return entities
    
    def _convert_primitive(self, primitive: GeometricPrimitive) -> CADEntity:
        """
        Convert a single primitive to CAD entity
        
        Args:
            primitive: Geometric primitive
            
        Returns:
            CAD entity
        """
        if primitive.primitive_type.value == 'line':
            return self._convert_line(primitive)
        elif primitive.primitive_type.value == 'circle':
            return self._convert_circle(primitive)
        elif primitive.primitive_type.value == 'arc':
            return self._convert_arc(primitive)
        elif primitive.primitive_type.value == 'polyline':
            return self._convert_polyline(primitive)
        else:
            logger.warning(f"Unknown primitive type: {primitive.primitive_type}")
            return None
    
    def _convert_line(self, primitive: GeometricPrimitive) -> CADEntity:
        """Convert line primitive to CAD LINE entity"""
        p = primitive.params
        
        return CADEntity(
            entity_type='LINE',
            layer=self.default_layer,
            properties={
                'start': (float(p['x1']), float(p['y1']), 0.0),
                'end': (float(p['x2']), float(p['y2']), 0.0),
                'color': self.line_color,
                'weight': self.line_weight
            }
        )
    
    def _convert_circle(self, primitive: GeometricPrimitive) -> CADEntity:
        """Convert circle primitive to CAD CIRCLE entity"""
        p = primitive.params
        
        return CADEntity(
            entity_type='CIRCLE',
            layer=self.default_layer,
            properties={
                'center': (float(p['center_x']), float(p['center_y']), 0.0),
                'radius': float(p['radius']),
                'color': self.line_color,
                'weight': self.line_weight
            }
        )
    
    def _convert_arc(self, primitive: GeometricPrimitive) -> CADEntity:
        """Convert arc primitive to CAD ARC entity"""
        p = primitive.params
        
        # Convert angles to radians for DXF
        start_angle_rad = np.radians(p['start_angle'])
        end_angle_rad = np.radians(p['end_angle'])
        
        return CADEntity(
            entity_type='ARC',
            layer=self.default_layer,
            properties={
                'center': (float(p['center_x']), float(p['center_y']), 0.0),
                'radius': float(p['radius']),
                'start_angle': float(p['start_angle']),
                'end_angle': float(p['end_angle']),
                'color': self.line_color,
                'weight': self.line_weight
            }
        )
    
    def _convert_polyline(self, primitive: GeometricPrimitive) -> CADEntity:
        """Convert polyline primitive to CAD LWPOLYLINE entity"""
        p = primitive.params
        points = p['points']
        
        # Convert points to 3D format
        vertices = [(float(x), float(y), 0.0) for x, y in points]
        
        return CADEntity(
            entity_type='LWPOLYLINE',
            layer=self.default_layer,
            properties={
                'vertices': vertices,
                'closed': p.get('closed', False),
                'color': self.line_color,
                'weight': self.line_weight
            }
        )
    
    def optimize_entities(self, entities: List[CADEntity], 
                         tolerance: float = 1.0) -> List[CADEntity]:
        """
        Optimize CAD entities by merging duplicates and simplifying
        
        Args:
            entities: List of CAD entities
            tolerance: Tolerance for considering entities as duplicates
            
        Returns:
            Optimized list of entities
        """
        # Remove duplicate entities
        unique = []
        seen = set()
        
        for entity in entities:
            key = self._entity_key(entity)
            if key not in seen:
                seen.add(key)
                unique.append(entity)
        
        logger.info(f"Optimized from {len(entities)} to {len(unique)} entities")
        return unique
    
    def _entity_key(self, entity: CADEntity) -> tuple:
        """Generate a hashable key for an entity"""
        props = entity.properties
        if entity.entity_type == 'LINE':
            return (entity.entity_type, props['start'], props['end'])
        elif entity.entity_type == 'CIRCLE':
            return (entity.entity_type, props['center'], props['radius'])
        elif entity.entity_type == 'ARC':
            return (entity.entity_type, props['center'], props['radius'], 
                   props['start_angle'], props['end_angle'])
        else:
            return (entity.entity_type, str(props))