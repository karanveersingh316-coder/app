"""
UI Module
Desktop interface using PyQt6
"""

import sys
import logging
from pathlib import Path
from typing import Optional

import numpy as np
import cv2

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QProgressBar, QTextEdit,
    QGroupBox, QSpinBox, QDoubleSpinBox, QCheckBox, QComboBox,
    QMessageBox, QSplitter, QFrame, QStatusBar
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QRunnable, QThreadPool, QObject
from PyQt6.QtGui import QImage, QPixmap, QFont, QIcon

# Import our modules
from image_loader import ImageLoader
from preprocessor import Preprocessor
from ai_model import EdgeDetectionAI
from geometry_extractor import GeometryExtractor
from vectorizer import Vectorizer
from dxf_generator import DXFGenerator

logger = logging.getLogger(__name__)


class ProcessingWorker(QRunnable):
    """Worker thread for image processing"""
    
    def __init__(self, image_path: str, output_path: str, params: dict):
        super().__init__()
        self.image_path = image_path
        self.output_path = output_path
        self.params = params
        self.signals = WorkerSignals()
    
    def run(self):
        """Run the processing pipeline"""
        try:
            self.signals.progress.emit(0, "Loading image...")
            
            # Initialize components
            loader = ImageLoader(max_dim=self.params.get('max_dim', 2048))
            preprocessor = Preprocessor()
            ai_model = EdgeDetectionAI()  # Uses traditional if no ONNX model
            extractor = GeometryExtractor(
                line_threshold=self.params.get('line_threshold', 100),
                min_line_length=self.params.get('min_line_length', 50)
            )
            vectorizer = Vectorizer()
            dxf_gen = DXFGenerator()
            
            # Load image
            image = loader.load(self.image_path)
            if image is None:
                self.signals.error.emit("Failed to load image")
                return
            
            self.signals.progress.emit(10, "Preprocessing...")
            
            # Preprocess
            processed, edges = preprocessor.preprocess_pipeline(image)
            
            self.signals.progress.emit(30, "Detecting edges...")
            
            # Edge detection (AI or traditional)
            edge_map = ai_model.detect_edges(processed)
            
            self.signals.progress.emit(50, "Extracting geometry...")
            
            # Extract geometric primitives
            primitives = extractor.extract_all(edge_map)
            
            if len(primitives) == 0:
                self.signals.error.emit("No geometry detected")
                return
            
            self.signals.progress.emit(70, "Vectorizing...")
            
            # Vectorize
            entities = vectorizer.vectorize(primitives)
            entities = vectorizer.optimize_entities(entities)
            
            self.signals.progress.emit(90, "Generating DXF...")
            
            # Generate DXF
            success = dxf_gen.create_dxf(entities, self.output_path)
            
            if success:
                stats = dxf_gen.get_entity_statistics(entities)
                self.signals.progress.emit(100, "Complete!")
                self.signals.finished.emit(stats)
            else:
                self.signals.error.emit("Failed to generate DXF")
                
        except Exception as e:
            logger.error(f"Processing error: {e}")
            self.signals.error.emit(str(e))


class WorkerSignals(QObject):
    """Signals for worker thread"""
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)


class AI2DXFMainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AI2DXF - Image to CAD Converter")
        self.setMinimumSize(1200, 800)
        
        self.current_image_path: Optional[str] = None
        self.current_image: Optional[np.ndarray] = None
        self.threadpool = QThreadPool()
        
        self._setup_ui()
        self._setup_logging()
    
    def _setup_ui(self):
        """Setup user interface"""
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        
        # Main layout
        layout = QHBoxLayout(central)
        
        # Splitter for resizable panels
        splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(splitter)
        
        # Left panel - Controls
        left_panel = self._create_control_panel()
        splitter.addWidget(left_panel)
        
        # Right panel - Preview
        right_panel = self._create_preview_panel()
        splitter.addWidget(right_panel)
        
        # Set splitter sizes
        splitter.setSizes([400, 800])
        
        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
    
    def _create_control_panel(self) -> QWidget:
        """Create left control panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Title
        title = QLabel("AI2DXF Converter")
        title.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        # File selection group
        file_group = QGroupBox("Input / Output")
        file_layout = QVBoxLayout(file_group)
        
        self.lbl_image = QLabel("No image selected")
        self.lbl_image.setWordWrap(True)
        file_layout.addWidget(self.lbl_image)
        
        btn_load = QPushButton("Load Image")
        btn_load.clicked.connect(self.load_image)
        file_layout.addWidget(btn_load)
        
        btn_output = QPushButton("Set Output Path")
        btn_output.clicked.connect(self.set_output_path)
        file_layout.addWidget(btn_output)
        
        self.lbl_output = QLabel("output.dxf")
        file_layout.addWidget(self.lbl_output)
        
        layout.addWidget(file_group)
        
        # Parameters group
        params_group = QGroupBox("Parameters")
        params_layout = QVBoxLayout(params_group)
        
        # Max dimension
        dim_layout = QHBoxLayout()
        dim_layout.addWidget(QLabel("Max Dimension:"))
        self.spin_max_dim = QSpinBox()
        self.spin_max_dim.setRange(512, 4096)
        self.spin_max_dim.setValue(2048)
        self.spin_max_dim.setSingleStep(256)
        dim_layout.addWidget(self.spin_max_dim)
        params_layout.addLayout(dim_layout)
        
        # Line threshold
        thresh_layout = QHBoxLayout()
        thresh_layout.addWidget(QLabel("Line Threshold:"))
        self.spin_threshold = QSpinBox()
        self.spin_threshold.setRange(10, 500)
        self.spin_threshold.setValue(100)
        thresh_layout.addWidget(self.spin_threshold)
        params_layout.addLayout(thresh_layout)
        
        # Min line length
        length_layout = QHBoxLayout()
        length_layout.addWidget(QLabel("Min Line Length:"))
        self.spin_min_length = QSpinBox()
        self.spin_min_length.setRange(5, 200)
        self.spin_min_length.setValue(50)
        length_layout.addWidget(self.spin_min_length)
        params_layout.addLayout(length_layout)
        
        layout.addWidget(params_group)
        
        # Process button
        self.btn_process = QPushButton("Convert to DXF")
        self.btn_process.setEnabled(False)
        self.btn_process.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-size: 14px;
                padding: 10px;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
        """)
        self.btn_process.clicked.connect(self.process_image)
        layout.addWidget(self.btn_process)
        
        # Progress bar
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        layout.addWidget(self.progress)
        
        self.lbl_status = QLabel("Ready")
        self.lbl_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.lbl_status)
        
        # Log output
        log_group = QGroupBox("Log")
        log_layout = QVBoxLayout(log_group)
        
        self.txt_log = QTextEdit()
        self.txt_log.setReadOnly(True)
        log_layout.addWidget(self.txt_log)
        
        layout.addWidget(log_group)
        
        layout.addStretch()
        
        return panel
    
    def _create_preview_panel(self) -> QWidget:
        """Create right preview panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Preview tabs
        preview_label = QLabel("Image Preview")
        preview_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        layout.addWidget(preview_label)
        
        # Original image
        orig_group = QGroupBox("Original")
        orig_layout = QVBoxLayout(orig_group)
        
        self.lbl_original = QLabel("No image loaded")
        self.lbl_original.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_original.setMinimumHeight(250)
        self.lbl_original.setStyleSheet("background-color: #f0f0f0; border: 1px solid #ccc;")
        orig_layout.addWidget(self.lbl_original)
        
        layout.addWidget(orig_group)
        
        # Edge detection result
        edge_group = QGroupBox("Edge Detection")
        edge_layout = QVBoxLayout(edge_group)
        
        self.lbl_edges = QLabel("Process image to see edges")
        self.lbl_edges.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_edges.setMinimumHeight(250)
        self.lbl_edges.setStyleSheet("background-color: #f0f0f0; border: 1px solid #ccc;")
        edge_layout.addWidget(self.lbl_edges)
        
        layout.addWidget(edge_group)
        
        return panel
    
    def _setup_logging(self):
        """Setup logging to GUI"""
        class GUILogHandler(logging.Handler):
            def __init__(self, gui):
                super().__init__()
                self.gui = gui
            
            def emit(self, record):
                msg = self.format(record)
                self.gui.log_message(msg)
        
        handler = GUILogHandler(self)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(levelname)s: %(message)s')
        handler.setFormatter(formatter)
        
        logging.getLogger().addHandler(handler)
    
    def log_message(self, msg: str):
        """Add message to log"""
        self.txt_log.append(msg)
    
    def load_image(self):
        """Load image file"""
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Image",
            "",
            "Images (*.png *.jpg *.jpeg *.bmp *.tiff)"
        )
        
        if path:
            self.current_image_path = path
            self.lbl_image.setText(Path(path).name)
            
            # Load and display preview
            loader = ImageLoader()
            self.current_image = loader.load(path)
            
            if self.current_image is not None:
                self.display_image(self.current_image, self.lbl_original)
                self.btn_process.setEnabled(True)
                self.status_bar.showMessage(f"Loaded: {Path(path).name}")
            else:
                QMessageBox.critical(self, "Error", "Failed to load image")
    
    def set_output_path(self):
        """Set output DXF file path"""
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save DXF",
            "output.dxf",
            "DXF Files (*.dxf)"
        )
        
        if path:
            if not path.endswith('.dxf'):
                path += '.dxf'
            self.lbl_output.setText(path)
    
    def display_image(self, image: np.ndarray, label: QLabel):
        """Display image in QLabel"""
        # Convert BGR to RGB
        if len(image.shape) == 3:
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        else:
            rgb_image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        
        # Resize to fit label while maintaining aspect ratio
        h, w = rgb_image.shape[:2]
        max_size = 400
        
        if max(h, w) > max_size:
            scale = max_size / max(h, w)
            new_w = int(w * scale)
            new_h = int(h * scale)
            rgb_image = cv2.resize(rgb_image, (new_w, new_h))
        
        # Convert to QPixmap
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image)
        
        label.setPixmap(pixmap)
    
    def process_image(self):
        """Start image processing"""
        if not self.current_image_path:
            QMessageBox.warning(self, "Warning", "Please load an image first")
            return
        
        output_path = self.lbl_output.text()
        
        # Get parameters
        params = {
            'max_dim': self.spin_max_dim.value(),
            'line_threshold': self.spin_threshold.value(),
            'min_line_length': self.spin_min_length.value()
        }
        
        # Disable controls
        self.btn_process.setEnabled(False)
        self.progress.setValue(0)
        
        # Create and start worker
        worker = ProcessingWorker(self.current_image_path, output_path, params)
        worker.signals.progress.connect(self.update_progress)
        worker.signals.finished.connect(self.processing_finished)
        worker.signals.error.connect(self.processing_error)
        
        self.threadpool.start(worker)
    
    def update_progress(self, value: int, message: str):
        """Update progress bar and status"""
        self.progress.setValue(value)
        self.lbl_status.setText(message)
        self.status_bar.showMessage(message)
    
    def processing_finished(self, stats: dict):
        """Handle processing completion"""
        self.btn_process.setEnabled(True)
        
        msg = f"""Conversion complete!
        
Entities created:
- Lines: {stats['lines']}
- Circles: {stats['circles']}
- Arcs: {stats['arcs']}
- Polylines: {stats['polylines']}
- Total: {stats['total']}

File saved to: {self.lbl_output.text()}
        """
        
        QMessageBox.information(self, "Success", msg)
        self.status_bar.showMessage("Ready")
    
    def processing_error(self, error_msg: str):
        """Handle processing error"""
        self.btn_process.setEnabled(True)
        self.progress.setValue(0)
        
        QMessageBox.critical(self, "Error", f"Processing failed:\n{error_msg}")
        self.status_bar.showMessage("Error occurred")


def main():
    """Main entry point"""
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # Set application font
    font = QFont("Segoe UI", 10)
    app.setFont(font)
    
    window = AI2DXFMainWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
