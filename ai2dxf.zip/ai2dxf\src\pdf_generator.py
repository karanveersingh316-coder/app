"""
PDF Generator Module
Generates technical PDF drawings from CAD entities
"""

import matplotlib
matplotlib.use('Agg')  # Non-interactive backend

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import Arc, Circle, FancyBboxPatch
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from pathlib import Path
from typing import List, Tuple, Optional
import numpy as np
import logging

from vectorizer import CADEntity

logger = logging.getLogger(__name__)


class PDFGenerator:
    """Generates technical PDF drawings"""
    
    def __init__(self, page_size: Tuple[float, float] = landscape(A4)):
        """
        Initialize PDF generator
        
        Args:
            page_size: Page size in points (default: A4 landscape)
        """
        self.page_size = page_size
        self.width, self.height = page_size
        
        logger.info("PDFGenerator initialized")
    
    def create_pdf(self, entities: List[CADEntity], 
                   output_path: str,
                   title: str = "Technical Drawing",
                   add_dimensions: bool = True,
                   tolerance: float = 0.1) -> bool:
        """
        Create PDF technical drawing
        
        Args:
            entities: List of CAD entities
            output_path: Output PDF path
            title: Drawing title
            add_dimensions: Whether to add dimensions
            tolerance: Dimensional tolerance
            
        Returns:
            True if successful
        """
        try:
            # Create PDF with ReportLab
            doc = SimpleDocTemplate(
                output_path,
                pagesize=self.page_size,
                rightMargin=20*mm,
                leftMargin=20*mm,
                topMargin=20*mm,
                bottomMargin=20*mm
            )
            
            # Build content
            story = []
            styles = getSampleStyleSheet()
            
            # Title
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=18,
                spaceAfter=20,
                alignment=1  # Center
            )
            story.append(Paragraph(title, title_style))
            story.append(Spacer(1, 10*mm))
            
            # Create drawing with matplotlib
            drawing_path = self._create_drawing_image(entities, add_dimensions, tolerance)
            
            if drawing_path and Path(drawing_path).exists():
                # Add drawing image
                img = Image(drawing_path, width=250*mm, height=150*mm)
                story.append(img)
                story.append(Spacer(1, 10*mm))
            
            # Add tolerance table
            story.append(self._create_tolerance_table())
            story.append(Spacer(1, 10*mm))
            
            # Add material info
            story.append(self._create_material_section())
            
            # Build PDF
            doc.build(story)
            
            # Clean up temp file
            if drawing_path and Path(drawing_path).exists():
                Path(drawing_path).unlink()
            
            logger.info(f"PDF file saved: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create PDF: {e}")
            return False
    
    def _create_drawing_image(self, entities: List[CADEntity],
                             add_dimensions: bool,
                             tolerance: float) -> Optional[str]:
        """
        Create drawing image using matplotlib
        
        Returns:
            Path to temporary image file
        """
        try:
            fig, ax = plt.subplots(figsize=(10, 7), dpi=150)
            ax.set_aspect('equal')
            
            # Calculate bounding box
            all_points = []
            for entity in entities:
                pts = self._get_entity_points(entity)
                all_points.extend(pts)
            
            if not all_points:
                return None
            
            all_points = np.array(all_points)
            min_x, min_y = all_points.min(axis=0)
            max_x, max_y = all_points.max(axis=0)
            
            # Add margin
            margin = max(max_x - min_x, max_y - min_y) * 0.1
            ax.set_xlim(min_x - margin, max_x + margin)
            ax.set_ylim(min_y - margin, max_y + margin)
            
            # Draw entities
            for entity in entities:
                self._draw_entity(ax, entity, add_dimensions, tolerance)
            
            # Style
            ax.set_xlabel('X [mm]', fontsize=10)
            ax.set_ylabel('Y [mm]', fontsize=10)
            ax.grid(True, alpha=0.3)
            ax.set_title('Technical Drawing View', fontsize=12, fontweight='bold')
            
            # Save to temp file
            temp_path = str(Path(output_path).parent / "_temp_drawing.png")
            plt.tight_layout()
            plt.savefig(temp_path, dpi=150, bbox_inches='tight', 
                       facecolor='white', edgecolor='none')
            plt.close()
            
            return temp_path
            
        except Exception as e:
            logger.error(f"Failed to create drawing image: {e}")
            return None
    
    def _get_entity_points(self, entity: CADEntity) -> List[Tuple[float, float]]:
        """Get all points from an entity"""
        points = []
        p = entity.properties
        
        if entity.entity_type == 'LINE':
            points.append((p['start'][0], p['start'][1]))
            points.append((p['end'][0], p['end'][1]))
        elif entity.entity_type == 'CIRCLE':
            center = p['center']
            radius = p['radius']
            for angle in np.linspace(0, 2*np.pi, 36):
                points.append((
                    center[0] + radius * np.cos(angle),
                    center[1] + radius * np.sin(angle)
                ))
        elif entity.entity_type == 'ARC':
            center = p['center']
            radius = p['radius']
            start_angle = np.radians(p['start_angle'])
            end_angle = np.radians(p['end_angle'])
            for angle in np.linspace(start_angle, end_angle, 20):
                points.append((
                    center[0] + radius * np.cos(angle),
                    center[1] + radius * np.sin(angle)
                ))
        elif entity.entity_type == 'LWPOLYLINE':
            for vertex in p['vertices']:
                points.append((vertex[0], vertex[1]))
        
        return points
    
    def _draw_entity(self, ax, entity: CADEntity, 
                    add_dimensions: bool, tolerance: float) -> None:
        """Draw a single entity on matplotlib axes"""
        p = entity.properties
        
        if entity.entity_type == 'LINE':
            start = p['start']
            end = p['end']
            ax.plot([start[0], end[0]], [start[1], end[1]], 
                   'k-', linewidth=1.5)
            
            if add_dimensions:
                # Add dimension text
                mid_x = (start[0] + end[0]) / 2
                mid_y = (start[1] + end[1]) / 2
                length = np.sqrt((end[0]-start[0])**2 + (end[1]-start[1])**2)
                ax.annotate(f'{length:.1f}±{tolerance}', 
                           xy=(mid_x, mid_y), fontsize=7,
                           bbox=dict(boxstyle='round,pad=0.3', 
                                    facecolor='yellow', alpha=0.7))
        
        elif entity.entity_type == 'CIRCLE':
            center = p['center']
            radius = p['radius']
            circle = Circle((center[0], center[1]), radius, 
                          fill=False, edgecolor='black', linewidth=1.5)
            ax.add_patch(circle)
            
            if add_dimensions:
                # Add diameter dimension
                ax.annotate(f'⌀{radius*2:.1f}±{tolerance}', 
                           xy=(center[0], center[1]), fontsize=7,
                           ha='center', va='center',
                           bbox=dict(boxstyle='round,pad=0.3',
                                    facecolor='lightblue', alpha=0.7))
        
        elif entity.entity_type == 'ARC':
            center = p['center']
            radius = p['radius']
            start_angle = p['start_angle']
            end_angle = p['end_angle']
            
            arc = Arc((center[0], center[1]), radius*2, radius*2,
                     angle=0, theta1=start_angle, theta2=end_angle,
                     edgecolor='black', linewidth=1.5)
            ax.add_patch(arc)
            
            if add_dimensions:
                mid_angle = np.radians((start_angle + end_angle) / 2)
                label_x = center[0] + radius * 0.7 * np.cos(mid_angle)
                label_y = center[1] + radius * 0.7 * np.sin(mid_angle)
                ax.annotate(f'R{radius:.1f}', 
                           xy=(label_x, label_y), fontsize=7,
                           bbox=dict(boxstyle='round,pad=0.3',
                                    facecolor='lightgreen', alpha=0.7))
        
        elif entity.entity_type == 'LWPOLYLINE':
            vertices = p['vertices']
            if len(vertices) >= 2:
                x_coords = [v[0] for v in vertices]
                y_coords = [v[1] for v in vertices]
                if p.get('closed', False):
                    x_coords.append(vertices[0][0])
                    y_coords.append(vertices[0][1])
                ax.plot(x_coords, y_coords, 'k-', linewidth=1.5)
    
    def _create_tolerance_table(self) -> Table:
        """Create tolerance table for PDF"""
        data = [
            ['Parameter', 'Tolerance'],
            ['Linear Dimensions', f'±{0.1} mm'],
            ['Diameters', f'±{0.05} mm'],
            ['Radii', f'±{0.05} mm'],
            ['Angles', f'±{0.5}°'],
        ]
        
        table = Table(data, colWidths=[60*mm, 40*mm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
        ]))
        
        return table
    
    def _create_material_section(self) -> Table:
        """Create material information section"""
        data = [
            ['Property', 'Value'],
            ['Material', 'Steel S235JR'],
            ['Treatment', 'None'],
            ['Finish', 'Painted'],
            ['Weight', '~0.5 kg'],
        ]
        
        table = Table(data, colWidths=[50*mm, 80*mm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
        ]))
        
        return table
    
    def get_statistics(self, entities: List[CADEntity]) -> dict:
        """Get statistics about entities"""
        stats = {
            'total': len(entities),
            'lines': sum(1 for e in entities if e.entity_type == 'LINE'),
            'circles': sum(1 for e in entities if e.entity_type == 'CIRCLE'),
            'arcs': sum(1 for e in entities if e.entity_type == 'ARC'),
            'polylines': sum(1 for e in entities if e.entity_type == 'LWPOLYLINE'),
        }
        return stats


# Global for temp file path
output_path = ""
