"""
AI Model Module
Edge detection using ONNX models for offline inference
"""

import numpy as np
import cv2
from pathlib import Path
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# Try to import ONNX runtime
try:
    import onnxruntime as ort
    ONNX_AVAILABLE = True
except ImportError:
    ONNX_AVAILABLE = False
    logger.warning("ONNX Runtime not available. Using traditional edge detection.")


class EdgeDetectionAI:
    """
    AI-powered edge detection using ONNX models
    Falls back to traditional methods if ONNX is not available
    """
    
    def __init__(self, model_path: Optional[str] = None, use_gpu: bool = False):
        """
        Initialize edge detection AI
        
        Args:
            model_path: Path to ONNX model file
            use_gpu: Whether to use GPU acceleration
        """
        self.model_path = model_path
        self.use_gpu = use_gpu
        self.session = None
        self.input_name = None
        self.input_shape = None
        
        if ONNX_AVAILABLE and model_path and Path(model_path).exists():
            self._load_model()
        else:
            logger.info("Using traditional edge detection (no AI model loaded)")
    
    def _load_model(self):
        """Load ONNX model"""
        try:
            # Configure session options
            sess_options = ort.SessionOptions()
            sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            
            # Configure providers
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider'] if self.use_gpu else ['CPUExecutionProvider']
            
            # Load model
            self.session = ort.InferenceSession(self.model_path, sess_options, providers=providers)
            
            # Get input info
            self.input_name = self.session.get_inputs()[0].name
            self.input_shape = self.session.get_inputs()[0].shape
            
            logger.info(f"ONNX model loaded: {self.model_path}")
            logger.info(f"Input shape: {self.input_shape}")
            
        except Exception as e:
            logger.error(f"Failed to load ONNX model: {e}")
            self.session = None
    
    def detect_edges(self, image: np.ndarray, 
                     target_size: Tuple[int, int] = (512, 512)) -> np.ndarray:
        """
        Detect edges in image
        
        Args:
            image: Input image (grayscale or BGR)
            target_size: Size for model input
            
        Returns:
            Edge map (binary image)
        """
        if self.session is not None:
            return self._detect_edges_ai(image, target_size)
        else:
            return self._detect_edges_traditional(image)
    
    def _detect_edges_ai(self, image: np.ndarray, 
                         target_size: Tuple[int, int]) -> np.ndarray:
        """
        Detect edges using AI model
        
        Args:
            image: Input image
            target_size: Model input size
            
        Returns:
            Edge map
        """
        original_shape = image.shape[:2]
        
        # Preprocess
        input_tensor = self._preprocess(image, target_size)
        
        # Run inference
        outputs = self.session.run(None, {self.input_name: input_tensor})
        
        # Postprocess
        edge_map = self._postprocess(outputs[0], original_shape)
        
        logger.info("AI edge detection completed")
        return edge_map
    
    def _detect_edges_traditional(self, image: np.ndarray) -> np.ndarray:
        """
        Detect edges using traditional computer vision
        
        Args:
            image: Input image
            
        Returns:
            Edge map
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # Apply Gaussian blur
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Canny edge detection with automatic thresholds
        median = np.median(blurred)
        lower = int(max(0, 0.66 * median))
        upper = int(min(255, 1.33 * median))
        
        edges = cv2.Canny(blurred, lower, upper)
        
        # Dilate to connect nearby edges
        kernel = np.ones((2, 2), np.uint8)
        edges = cv2.dilate(edges, kernel, iterations=1)
        
        logger.info("Traditional edge detection completed")
        return edges
    
    def _preprocess(self, image: np.ndarray, 
                    target_size: Tuple[int, int]) -> np.ndarray:
        """
        Preprocess image for model input
        
        Args:
            image: Input image
            target_size: Target size
            
        Returns:
            Preprocessed tensor
        """
        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # Resize
        resized = cv2.resize(gray, target_size, interpolation=cv2.INTER_AREA)
        
        # Normalize to 0-1
        normalized = resized.astype(np.float32) / 255.0
        
        # Add batch and channel dimensions
        # ONNX typically expects NCHW format
        tensor = np.expand_dims(normalized, axis=(0, 1))
        
        return tensor
    
    def _postprocess(self, output: np.ndarray, 
                     original_shape: Tuple[int, int]) -> np.ndarray:
        """
        Postprocess model output
        
        Args:
            output: Model output
            original_shape: Original image shape (H, W)
            
        Returns:
            Binary edge map
        """
        # Remove batch dimension if present
        if output.ndim == 4:
            output = output[0, 0]
        elif output.ndim == 3:
            output = output[0]
        
        # Resize to original size
        edge_map = cv2.resize(output, (original_shape[1], original_shape[0]), 
                              interpolation=cv2.INTER_LINEAR)
        
        # Normalize to 0-255
        edge_map = (edge_map * 255).astype(np.uint8)
        
        # Threshold to binary
        _, binary = cv2.threshold(edge_map, 127, 255, cv2.THRESH_BINARY)
        
        return binary
    
    @staticmethod
    def download_model(model_name: str = "hed", 
                       output_dir: str = "models") -> Optional[str]:
        """
        Download a pre-trained edge detection model
        
        Args:
            model_name: Name of the model ('hed' or 'dexined')
            output_dir: Directory to save model
            
        Returns:
            Path to downloaded model or None
        """
        # This is a placeholder - in production, you'd download from a model zoo
        logger.info(f"Model download not implemented. Please manually place ONNX model in {output_dir}")
        return None


class TraditionalEdgeDetector:
    """
    Traditional computer vision edge detection
    Used as fallback when AI model is not available
    """
    
    @staticmethod
    def sobel_edges(image: np.ndarray) -> np.ndarray:
        """Detect edges using Sobel operator"""
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        
        magnitude = np.sqrt(sobelx**2 + sobely**2)
        magnitude = np.uint8(255 * magnitude / magnitude.max())
        
        return magnitude
    
    @staticmethod
    def laplacian_edges(image: np.ndarray) -> np.ndarray:
        """Detect edges using Laplacian operator"""
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        laplacian = np.uint8(np.absolute(laplacian))
        
        return laplacian
