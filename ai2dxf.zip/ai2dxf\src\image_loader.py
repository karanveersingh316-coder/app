"""
Image Loader Module
Handles image loading, validation, and initial preprocessing
"""

import cv2
import numpy as np
from pathlib import Path
from typing import Tuple, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ImageLoader:
    """Loads and validates input images for processing"""
    
    # Supported formats
    SUPPORTED_FORMATS = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
    
    # Maximum dimensions to prevent memory issues
    MAX_DIMENSION = 4096
    TARGET_SIZE = (1024, 1024)  # Resize to this for processing
    
    def __init__(self, max_dim: int = 2048):
        """
        Initialize image loader
        
        Args:
            max_dim: Maximum dimension for resizing large images
        """
        self.max_dim = max_dim
        logger.info(f"ImageLoader initialized with max_dim={max_dim}")
    
    def load(self, image_path: str) -> Optional[np.ndarray]:
        """
        Load and validate an image file
        
        Args:
            image_path: Path to the image file
            
        Returns:
            Loaded image as numpy array or None if failed
        """
        path = Path(image_path)
        
        # Validate file exists
        if not path.exists():
            logger.error(f"File not found: {image_path}")
            return None
        
        # Validate format
        if path.suffix.lower() not in self.SUPPORTED_FORMATS:
            logger.error(f"Unsupported format: {path.suffix}")
            return None
        
        try:
            # Load image
            image = cv2.imread(str(path))
            
            if image is None:
                logger.error(f"Failed to load image: {image_path}")
                return None
            
            logger.info(f"Loaded image: {image.shape}")
            
            # Resize if too large
            image = self._resize_if_needed(image)
            
            return image
            
        except Exception as e:
            logger.error(f"Error loading image: {e}")
            return None
    
    def _resize_if_needed(self, image: np.ndarray) -> np.ndarray:
        """
        Resize image if it exceeds maximum dimensions
        
        Args:
            image: Input image
            
        Returns:
            Resized image
        """
        h, w = image.shape[:2]
        
        if max(h, w) > self.max_dim:
            # Calculate new size maintaining aspect ratio
            scale = self.max_dim / max(h, w)
            new_w = int(w * scale)
            new_h = int(h * scale)
            
            image = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_AREA)
            logger.info(f"Resized image to: {image.shape}")
        
        return image
    
    def to_grayscale(self, image: np.ndarray) -> np.ndarray:
        """
        Convert image to grayscale
        
        Args:
            image: Input image (BGR or RGB)
            
        Returns:
            Grayscale image
        """
        if len(image.shape) == 3:
            return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        return image
    
    def normalize(self, image: np.ndarray) -> np.ndarray:
        """
        Normalize image to 0-1 range
        
        Args:
            image: Input image
            
        Returns:
            Normalized float32 image
        """
        return image.astype(np.float32) / 255.0
    
    def prepare_for_ai(self, image: np.ndarray, target_size: Tuple[int, int] = (512, 512)) -> np.ndarray:
        """
        Prepare image for AI model inference
        
        Args:
            image: Input image
            target_size: Target size for model input
            
        Returns:
            Preprocessed image ready for AI
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = self.to_grayscale(image)
        else:
            gray = image
        
        # Resize to target size
        resized = cv2.resize(gray, target_size, interpolation=cv2.INTER_AREA)
        
        # Normalize
        normalized = self.normalize(resized)
        
        # Add batch and channel dimensions (NCHW format for ONNX)
        # Shape: (1, 1, H, W)
        tensor = np.expand_dims(normalized, axis=(0, 1))
        
        return tensor
    
    def get_image_info(self, image: np.ndarray) -> dict:
        """
        Get information about the image
        
        Args:
            image: Input image
            
        Returns:
            Dictionary with image information
        """
        h, w = image.shape[:2]
        channels = 1 if len(image.shape) == 2 else image.shape[2]
        
        return {
            'width': w,
            'height': h,
            'channels': channels,
            'aspect_ratio': w / h,
            'total_pixels': w * h
        }
