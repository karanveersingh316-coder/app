"""
Geometry Extractor Module
Detects geometric primitives (lines, circles, arcs) from edge maps
"""

import cv2
import numpy as np
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class PrimitiveType(Enum):
    """Types of geometric primitives"""
    LINE = "line"
    CIRCLE = "circle"
    ARC = "arc"
    POLYLINE = "polyline"


@dataclass
class GeometricPrimitive:
    """Represents a geometric primitive"""
    primitive_type: PrimitiveType
    params: Dict  # Parameters vary by type
    confidence: float
    
    def __repr__(self):
        return f"{self.primitive_type.value}: {self.params} (conf: {self.confidence:.2f})"


class GeometryExtractor:
    """Extracts geometric primitives from edge maps"""
    
    def __init__(self, 
                 line_threshold: int = 100,
                 circle_min_dist: int = 50,
                 circle_param1: int = 50,
                 circle_param2: int = 30,
                 min_line_length: int = 50,
                 max_line_gap: int = 10):
        """
        Initialize geometry extractor
        
        Args:
            line_threshold: Threshold for Hough line detection
            circle_min_dist: Minimum distance between circle centers
            circle_param1: Canny threshold for circle detection
            circle_param2: Accumulator threshold for circle detection
            min_line_length: Minimum line length
            max_line_gap: Maximum gap between line segments
        """
        self.line_threshold = line_threshold
        self.circle_min_dist = circle_min_dist
        self.circle_param1 = circle_param1
        self.circle_param2 = circle_param2
        self.min_line_length = min_line_length
        self.max_line_gap = max_line_gap
        
        logger.info("GeometryExtractor initialized")
    
    def extract_all(self, edge_map: np.ndarray) -> List[GeometricPrimitive]:
        """
        Extract all geometric primitives from edge map
        
        Args:
            edge_map: Binary edge image
            
        Returns:
            List of detected geometric primitives
        """
        primitives = []
        
        # Detect lines
        lines = self.detect_lines(edge_map)
        primitives.extend(lines)
        logger.info(f"Detected {len(lines)} lines")
        
        # Detect circles
        circles = self.detect_circles(edge_map)
        primitives.extend(circles)
        logger.info(f"Detected {len(circles)} circles")
        
        # Detect arcs (from remaining edges)
        arcs = self.detect_arcs(edge_map, lines, circles)
        primitives.extend(arcs)
        logger.info(f"Detected {len(arcs)} arcs")
        
        # Extract polylines from remaining contours
        polylines = self.detect_polylines(edge_map, lines, circles, arcs)
        primitives.extend(polylines)
        logger.info(f"Detected {len(polylines)} polylines")
        
        return primitives
    
    def detect_lines(self, edge_map: np.ndarray) -> List[GeometricPrimitive]:
        """
        Detect straight lines using Hough Transform
        
        Args:
            edge_map: Binary edge image
            
        Returns:
            List of line primitives
        """
        lines = cv2.HoughLinesP(
            edge_map, 
            rho=1, 
            theta=np.pi/180, 
            threshold=self.line_threshold,
            minLineLength=self.min_line_length,
            maxLineGap=self.max_line_gap
        )
        
        primitives = []
        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                
                # Calculate line properties
                length = np.sqrt((x2-x1)**2 + (y2-y1)**2)
                angle = np.arctan2(y2-y1, x2-x1) * 180 / np.pi
                
                primitive = GeometricPrimitive(
                    primitive_type=PrimitiveType.LINE,
                    params={
                        'x1': int(x1),
                        'y1': int(y1),
                        'x2': int(x2),
                        'y2': int(y2),
                        'length': float(length),
                        'angle': float(angle)
                    },
                    confidence=min(length / 100, 1.0)  # Confidence based on length
                )
                primitives.append(primitive)
        
        # Merge similar lines
        primitives = self._merge_similar_lines(primitives)
        
        return primitives
    
    def detect_circles(self, edge_map: np.ndarray) -> List[GeometricPrimitive]:
        """
        Detect circles using Hough Circle Transform
        
        Args:
            edge_map: Binary edge image
            
        Returns:
            List of circle primitives
        """
        # Need grayscale for HoughCircles
        if len(edge_map.shape) == 3:
            gray = cv2.cvtColor(edge_map, cv2.COLOR_BGR2GRAY)
        else:
            gray = edge_map
        
        circles = cv2.HoughCircles(
            gray,
            cv2.HOUGH_GRADIENT,
            dp=1,
            minDist=self.circle_min_dist,
            param1=self.circle_param1,
            param2=self.circle_param2,
            minRadius=10,
            maxRadius=min(gray.shape) // 2
        )
        
        primitives = []
        if circles is not None:
            circles = np.uint16(np.around(circles))
            
            for circle in circles[0, :]:
                x, y, radius = circle
                
                primitive = GeometricPrimitive(
                    primitive_type=PrimitiveType.CIRCLE,
                    params={
                        'center_x': int(x),
                        'center_y': int(y),
                        'radius': int(radius),
                        'diameter': int(radius * 2)
                    },
                    confidence=0.9  # Hough circles are usually reliable
                )
                primitives.append(primitive)
        
        return primitives
    
    def detect_arcs(self, edge_map: np.ndarray, 
                    lines: List[GeometricPrimitive],
                    circles: List[GeometricPrimitive]) -> List[GeometricPrimitive]:
        """
        Detect circular arcs from remaining edges
        
        Args:
            edge_map: Binary edge image
            lines: Already detected lines
            circles: Already detected circles
            
        Returns:
            List of arc primitives
        """
        # Create mask of used pixels
        mask = np.zeros_like(edge_map)
        
        # Mask out lines
        for line in lines:
            p = line.params
            cv2.line(mask, (p['x1'], p['y1']), (p['x2'], p['y2']), 255, 3)
        
        # Mask out circles
        for circle in circles:
            p = circle.params
            cv2.circle(mask, (p['center_x'], p['center_y']), p['radius'], 255, 3)
        
        # Get remaining edges
        remaining = cv2.bitwise_and(edge_map, cv2.bitwise_not(mask))
        
        # Find contours
        contours, _ = cv2.findContours(remaining, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        primitives = []
        for contour in contours:
            if len(contour) < 20:  # Skip small contours
                continue
            
            # Try to fit circle to contour
            (x, y), radius = cv2.minEnclosingCircle(contour)
            
            # Check if it's actually an arc (not a full circle)
            circle_area = np.pi * radius ** 2
            contour_area = cv2.contourArea(contour)
            
            if contour_area < circle_area * 0.7:  # Less than 70% of circle = arc
                # Calculate arc angles
                angles = []
                for point in contour:
                    px, py = point[0]
                    angle = np.arctan2(py - y, px - x)
                    angles.append(angle)
                
                start_angle = min(angles) * 180 / np.pi
                end_angle = max(angles) * 180 / np.pi
                
                primitive = GeometricPrimitive(
                    primitive_type=PrimitiveType.ARC,
                    params={
                        'center_x': int(x),
                        'center_y': int(y),
                        'radius': int(radius),
                        'start_angle': float(start_angle),
                        'end_angle': float(end_angle)
                    },
                    confidence=contour_area / circle_area
                )
                primitives.append(primitive)
        
        return primitives
    
    def detect_polylines(self, edge_map: np.ndarray,
                         lines: List[GeometricPrimitive],
                         circles: List[GeometricPrimitive],
                         arcs: List[GeometricPrimitive]) -> List[GeometricPrimitive]:
        """
        Extract polylines from remaining contours
        
        Args:
            edge_map: Binary edge image
            lines: Detected lines
            circles: Detected circles
            arcs: Detected arcs
            
        Returns:
            List of polyline primitives
        """
        # Create mask of used pixels
        mask = np.zeros_like(edge_map)
        
        for line in lines:
            p = line.params
            cv2.line(mask, (p['x1'], p['y1']), (p['x2'], p['y2']), 255, 3)
        
        for circle in circles:
            p = circle.params
            cv2.circle(mask, (p['center_x'], p['center_y']), p['radius'], 255, 3)
        
        for arc in arcs:
            p = arc.params
            # Draw arc
            cv2.ellipse(mask, (p['center_x'], p['center_y']), 
                       (p['radius'], p['radius']), 0,
                       p['start_angle'], p['end_angle'], 255, 3)
        
        # Get remaining edges
        remaining = cv2.bitwise_and(edge_map, cv2.bitwise_not(mask))
        
        # Find contours
        contours, _ = cv2.findContours(remaining, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        primitives = []
        for contour in contours:
            if len(contour) < 5:
                continue
            
            # Simplify contour
            epsilon = 0.01 * cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, epsilon, True)
            
            # Convert to list of points
            points = [(int(p[0][0]), int(p[0][1])) for p in approx]
            
            if len(points) >= 2:
                primitive = GeometricPrimitive(
                    primitive_type=PrimitiveType.POLYLINE,
                    params={
                        'points': points,
                        'closed': cv2.isContourConvex(approx) or len(points) > 2,
                        'num_points': len(points)
                    },
                    confidence=0.7
                )
                primitives.append(primitive)
        
        return primitives
    
    def _merge_similar_lines(self, lines: List[GeometricPrimitive], 
                            angle_threshold: float = 10,
                            distance_threshold: float = 20) -> List[GeometricPrimitive]:
        """
        Merge similar lines to reduce duplicates
        
        Args:
            lines: List of line primitives
            angle_threshold: Maximum angle difference in degrees
            distance_threshold: Maximum distance between lines
            
        Returns:
            Merged list of lines
        """
        if len(lines) < 2:
            return lines
        
        merged = []
        used = set()
        
        for i, line1 in enumerate(lines):
            if i in used:
                continue
            
            p1 = line1.params
            merged_line = line1
            
            for j, line2 in enumerate(lines[i+1:], start=i+1):
                if j in used:
                    continue
                
                p2 = line2.params
                
                # Check angle similarity
                angle_diff = abs(p1['angle'] - p2['angle'])
                if angle_diff > 180:
                    angle_diff = 360 - angle_diff
                
                if angle_diff > angle_threshold:
                    continue
                
                # Check distance (simplified - check midpoint distance)
                mid1 = ((p1['x1'] + p1['x2']) / 2, (p1['y1'] + p1['y2']) / 2)
                mid2 = ((p2['x1'] + p2['x2']) / 2, (p2['y1'] + p2['y2']) / 2)
                distance = np.sqrt((mid1[0] - mid2[0])**2 + (mid1[1] - mid2[1])**2)
                
                if distance < distance_threshold:
                    # Merge lines (use longer one)
                    if p2['length'] > p1['length']:
                        merged_line = line2
                    used.add(j)
            
            merged.append(merged_line)
            used.add(i)
        
        return merged
