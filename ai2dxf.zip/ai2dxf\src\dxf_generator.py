"""
DXF Generator Module
Generates DXF files from CAD entities using ezdxf library
Includes dimensions and tolerances
"""

import ezdxf
from ezdxf import units
from ezdxf.math import Vec2
from pathlib import Path
from typing import List, Optional, Tuple, Dict
import logging
import math

from vectorizer import CADEntity

logger = logging.getLogger(__name__)


class DXFGenerator:
    """Generates DXF files from CAD entities"""
    
    def __init__(self, 
                 units_type: int = units.MM,
                 drawing_name: str = "AI2DXF_Output"):
        """
        Initialize DXF generator
        
        Args:
            units_type: Drawing units (default: millimeters)
            drawing_name: Name of the drawing
        """
        self.units_type = units_type
        self.drawing_name = drawing_name
        
        logger.info("DXFGenerator initialized")
    
    def create_dxf(self, entities: List[CADEntity], 
                   output_path: str,
                   setup_layers: bool = True,
                   add_dimensions: bool = True,
                   add_title_block: bool = True,
                   tolerance: float = 0.1) -> bool:
        """
        Create DXF file from CAD entities
        
        Args:
            entities: List of CAD entities
            output_path: Output file path
            setup_layers: Whether to setup default layers
            add_dimensions: Whether to add dimension annotations
            add_title_block: Whether to add title block with tolerances
            tolerance: Dimensional tolerance value
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Create new DXF document
            doc = ezdxf.new('R2010')
            
            # Setup document
            doc.header['$INSUNITS'] = self.units_type
            msp = doc.modelspace()
            
            # Setup layers if requested
            if setup_layers:
                self._setup_layers(doc)
            
            # Add entities
            for entity in entities:
                self._add_entity(msp, entity)
            
            # Add dimensions with tolerances
            if add_dimensions:
                self.add_dimensions(msp, entities, tolerance)
                self.add_angular_dimensions(msp, entities, "AI2DXF_DIMSTYLE", tolerance * 5)
                self.add_center_marks(msp, entities)
            
            # Add title block with tolerance table
            if add_title_block:
                self.add_title_block(msp, title=self.drawing_name)
                self.add_iso_tolerance_table(msp, 10, 60)
                self.add_material_list(msp, 10, 120)
            
            # Add geometric tolerances
            self.add_geometric_tolerances(msp, entities)
            
            # Add surface roughness
            self.add_surface_roughness(msp, entities)
            
            # Add weld symbols
            self.add_weld_symbols(msp, entities)
            
            # Add section view indicator
            self.add_section_view_indicator(msp, Vec2(150, 180), "A-A")
            
            # Setup viewport
            self._setup_viewport(doc, msp)
            
            # Save file
            doc.saveas(output_path)
            
            logger.info(f"DXF file saved: {output_path}")
            logger.info(f"Total entities: {len(entities)}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to create DXF: {e}")
            return False
    
    def _setup_layers(self, doc):
        """Setup default layers"""
        # Layer 0 already exists by default, just modify it
        layer0 = doc.layers.get("0")
        layer0.color = 7  # White
        
        # Construction layer
        if "CONSTRUCTION" not in doc.layers:
            doc.layers.add("CONSTRUCTION",
                          color=1,  # Red
                          linetype="DASHED")
        
        # Dimensions layer
        if "DIMENSIONS" not in doc.layers:
            doc.layers.add("DIMENSIONS",
                          color=3)  # Green
        
        # Center lines
        if "CENTER" not in doc.layers:
            doc.layers.add("CENTER",
                          color=4,  # Cyan
                          linetype="CENTER")
        
        logger.debug("Default layers created")
    
    def _add_entity(self, msp, entity: CADEntity):
        """
        Add a CAD entity to modelspace
        
        Args:
            msp: Modelspace object
            entity: CAD entity to add
        """
        try:
            if entity.entity_type == 'LINE':
                self._add_line(msp, entity)
            elif entity.entity_type == 'CIRCLE':
                self._add_circle(msp, entity)
            elif entity.entity_type == 'ARC':
                self._add_arc(msp, entity)
            elif entity.entity_type == 'LWPOLYLINE':
                self._add_polyline(msp, entity)
            else:
                logger.warning(f"Unknown entity type: {entity.entity_type}")
                
        except Exception as e:
            logger.error(f"Failed to add entity {entity}: {e}")
    
    def _add_line(self, msp, entity: CADEntity):
        """Add LINE entity"""
        p = entity.properties
        start = p['start']
        end = p['end']
        
        msp.add_line(
            start=start[:2],  # ezdxf uses 2D points for LINE
            end=end[:2],
            dxfattribs={
                'layer': entity.layer,
                'color': p.get('color', 7)
            }
        )
    
    def _add_circle(self, msp, entity: CADEntity):
        """Add CIRCLE entity"""
        p = entity.properties
        center = p['center']
        
        msp.add_circle(
            center=center[:2],
            radius=p['radius'],
            dxfattribs={
                'layer': entity.layer,
                'color': p.get('color', 7)
            }
        )
    
    def _add_arc(self, msp, entity: CADEntity):
        """Add ARC entity"""
        p = entity.properties
        center = p['center']
        
        msp.add_arc(
            center=center[:2],
            radius=p['radius'],
            start_angle=p['start_angle'],
            end_angle=p['end_angle'],
            dxfattribs={
                'layer': entity.layer,
                'color': p.get('color', 7)
            }
        )
    
    def _add_polyline(self, msp, entity: CADEntity):
        """Add LWPOLYLINE entity"""
        p = entity.properties
        vertices = [(v[0], v[1]) for v in p['vertices']]
        
        if len(vertices) < 2:
            logger.warning("Polyline has less than 2 vertices, skipping")
            return
        
        msp.add_lwpolyline(
            points=vertices,
            close=p.get('closed', False),
            dxfattribs={
                'layer': entity.layer,
                'color': p.get('color', 7)
            }
        )
    
    def _setup_viewport(self, doc, msp):
        """Setup viewport for better viewing"""
        # Try to zoom to extents
        try:
            extents = msp.query_extents()
            if extents:
                # Add a paperspace layout with viewport
                layout = doc.layouts.new('Layout1')
                
                # Create viewport
                viewport = layout.add_viewport(
                    center=(150, 100),  # Center of A4 paper (in mm)
                    size=(250, 170),    # Viewport size
                    view_center_point=(0, 0),  # Will be updated
                    view_height=100
                )
                
                logger.debug("Viewport created")
        except Exception as e:
            logger.debug(f"Could not setup viewport: {e}")
    
    def _mm_to_lineweight(self, mm: float) -> int:
        """
        Convert mm to DXF lineweight value
        
        Args:
            mm: Line weight in millimeters
            
        Returns:
            DXF lineweight value
        """
        # DXF lineweights are in 1/100 mm, but must be valid values
        # Valid values: 0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, 211
        value = int(mm * 100)
        valid_weights = [0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, 211]
        
        # Find closest valid weight
        return min(valid_weights, key=lambda x: abs(x - value))
    
    def create_template_dxf(self, output_path: str) -> bool:
        """
        Create a template DXF file with standard settings
        
        Args:
            output_path: Output file path
            
        Returns:
            True if successful
        """
        try:
            doc = ezdxf.new('R2010')
            doc.header['$INSUNITS'] = self.units_type
            
            # Setup layers
            self._setup_layers(doc)
            
            # Add title block
            msp = doc.modelspace()
            
            # Add border
            width, height = 297, 210  # A4 landscape in mm
            msp.add_lwpolyline(
                points=[(0, 0), (width, 0), (width, height), (0, height)],
                close=True,
                dxfattribs={'layer': '0', 'color': 7}
            )
            
            # Save
            doc.saveas(output_path)
            logger.info(f"Template DXF created: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create template: {e}")
            return False
    
    def get_entity_statistics(self, entities: List[CADEntity]) -> dict:
        """
        Get statistics about entities
        
        Args:
            entities: List of CAD entities
            
        Returns:
            Dictionary with statistics
        """
        stats = {
            'total': len(entities),
            'lines': 0,
            'circles': 0,
            'arcs': 0,
            'polylines': 0,
            'other': 0
        }
        
        for entity in entities:
            etype = entity.entity_type
            if etype == 'LINE':
                stats['lines'] += 1
            elif etype == 'CIRCLE':
                stats['circles'] += 1
            elif etype == 'ARC':
                stats['arcs'] += 1
            elif etype == 'LWPOLYLINE':
                stats['polylines'] += 1
            else:
                stats['other'] += 1
        
        return stats
    
    def add_dimensions(self, msp, entities: List[CADEntity], 
                      tolerance: float = 0.1) -> None:
        """
        Add dimension annotations to entities
        
        Args:
            msp: Modelspace object
            entities: List of CAD entities
            tolerance: Dimensional tolerance (+/-)
        """
        dim_style = self._create_dimension_style(msp.doc)
        
        for entity in entities:
            if entity.entity_type == 'LINE':
                self._add_line_dimension(msp, entity, dim_style, tolerance)
            elif entity.entity_type == 'CIRCLE':
                self._add_circle_dimension(msp, entity, dim_style, tolerance)
            elif entity.entity_type == 'ARC':
                self._add_arc_dimension(msp, entity, dim_style, tolerance)
    
    def _create_dimension_style(self, doc) -> str:
        """Create a custom dimension style"""
        dim_style_name = "AI2DXF_DIMSTYLE"
        
        if dim_style_name not in doc.dimstyles:
            dimstyle = doc.dimstyles.new(dim_style_name)
            dimstyle.dxf.dimscale = 1.0
            dimstyle.dxf.dimtxt = 2.5  # Text height
            dimstyle.dxf.dimexe = 1.0  # Extension line extension
            dimstyle.dxf.dimexo = 1.0  # Extension line offset
            dimstyle.dxf.dimtad = 1    # Text above dimension line
            dimstyle.dxf.dimdec = 2    # Decimal places
        
        return dim_style_name
    
    def _add_line_dimension(self, msp, entity: CADEntity, 
                           dim_style: str, tolerance: float) -> None:
        """Add linear dimension to a line"""
        p = entity.properties
        start = Vec2(p['start'][0], p['start'][1])
        end = Vec2(p['end'][0], p['end'][1])
        
        # Calculate length
        length = (end - start).magnitude
        
        # Skip very short lines
        if length < 10:
            return
        
        # Calculate dimension line position (offset perpendicular to line)
        mid = (start + end) * 0.5
        direction = (end - start).normalize()
        perpendicular = Vec2(-direction.y, direction.x)
        dim_pos = mid + perpendicular * 15
        
        # Add dimension
        dim = msp.add_linear_dim(
            base=dim_pos,
            p1=start,
            p2=end,
            dimstyle=dim_style
        )
        
        # Add tolerance text
        tol_text = f"±{tolerance}"
        dim.set_text(f"{length:.1f} {tol_text}")
        dim.render()
    
    def _add_circle_dimension(self, msp, entity: CADEntity,
                             dim_style: str, tolerance: float) -> None:
        """Add diameter dimension to a circle"""
        p = entity.properties
        center = Vec2(p['center'][0], p['center'][1])
        radius = p['radius']
        diameter = radius * 2
        
        # Skip very small circles
        if diameter < 10:
            return
        
        # Dimension position (to the right of circle)
        dim_pos = center + Vec2(radius + 20, 0)
        
        # Add diameter dimension
        dim = msp.add_diameter_dim(
            center=center,
            radius=radius,
            angle=0,  # Horizontal dimension
            dimstyle=dim_style
        )
        
        # Add tolerance
        tol_text = f"±{tolerance}"
        dim.set_text(f"⌀{diameter:.1f} {tol_text}")
        dim.render()
    
    def _add_arc_dimension(self, msp, entity: CADEntity,
                          dim_style: str, tolerance: float) -> None:
        """Add radius dimension to an arc"""
        p = entity.properties
        center = Vec2(p['center'][0], p['center'][1])
        radius = p['radius']
        start_angle = math.radians(p['start_angle'])
        end_angle = math.radians(p['end_angle'])
        
        # Skip very small arcs
        if radius < 5:
            return
        
        # Calculate mid angle for dimension placement
        mid_angle = (start_angle + end_angle) / 2
        if end_angle < start_angle:
            mid_angle += math.pi
        
        # Point on arc for dimension
        arc_point = center + Vec2(
            radius * math.cos(mid_angle),
            radius * math.sin(mid_angle)
        )
        
        # Add radius dimension
        dim = msp.add_radius_dim(
            center=center,
            radius=radius,
            angle=math.degrees(mid_angle),
            dimstyle=dim_style
        )
        
        # Add tolerance
        tol_text = f"±{tolerance}"
        dim.set_text(f"R{radius:.1f} {tol_text}")
        dim.render()
    
    def add_title_block(self, msp, width: float = 297, height: float = 210,
                       title: str = "AI2DXF Drawing",
                       tolerance_table: bool = True) -> None:
        """
        Add title block with tolerance information
        
        Args:
            msp: Modelspace object
            width: Drawing width (A4 landscape default)
            height: Drawing height
            title: Drawing title
            tolerance_table: Add tolerance table
        """
        # Title block position (bottom right)
        tb_width = 100
        tb_height = 40
        tb_x = width - tb_width - 10
        tb_y = 10
        
        # Draw title block border
        msp.add_lwpolyline(
            points=[
                (tb_x, tb_y),
                (tb_x + tb_width, tb_y),
                (tb_x + tb_width, tb_y + tb_height),
                (tb_x, tb_y + tb_height)
            ],
            close=True,
            dxfattribs={'layer': '0', 'color': 7}
        )
        
        # Add title
        msp.add_text(
            title,
            height=3,
            dxfattribs={'insert': (tb_x + 5, tb_y + tb_height - 8)}
        )
        
        # Add tolerance table if requested
        if tolerance_table:
            self._add_tolerance_table(msp, tb_x + 5, tb_y + 5)
    
    def _add_tolerance_table(self, msp, x: float, y: float) -> None:
        """Add dimensional tolerance table"""
        tolerances = [
            ("Dimensioni lineari", "±0.1"),
            ("Diametri", "±0.05"),
            ("Raggi", "±0.05"),
            ("Angoli", "±0.5°")
        ]
        
        y_pos = y
        for label, value in tolerances:
            msp.add_text(
                f"{label}: {value}",
                height=2,
                dxfattribs={'insert': (x, y_pos)}
            )
            y_pos += 4
    
    def add_angular_dimensions(self, msp, entities: List[CADEntity],
                               dim_style: str, tolerance: float = 0.5) -> None:
        """
        Add angular dimensions between connected lines
        
        Args:
            msp: Modelspace object
            entities: List of CAD entities
            dim_style: Dimension style name
            tolerance: Angular tolerance in degrees
        """
        lines = [e for e in entities if e.entity_type == 'LINE']
        
        for i, line1 in enumerate(lines):
            for line2 in lines[i+1:]:
                # Check if lines share an endpoint
                p1 = line1.properties
                p2 = line2.properties
                
                start1 = Vec2(p1['start'][0], p1['start'][1])
                end1 = Vec2(p1['end'][0], p1['end'][1])
                start2 = Vec2(p2['start'][0], p2['start'][1])
                end2 = Vec2(p2['end'][0], p2['end'][1])
                
                # Find common point
                common = None
                if (start1 - start2).magnitude < 1:
                    common = start1
                    dir1 = (end1 - start1).normalize()
                    dir2 = (end2 - start2).normalize()
                elif (start1 - end2).magnitude < 1:
                    common = start1
                    dir1 = (end1 - start1).normalize()
                    dir2 = (start2 - end2).normalize()
                elif (end1 - start2).magnitude < 1:
                    common = end1
                    dir1 = (start1 - end1).normalize()
                    dir2 = (end2 - start2).normalize()
                elif (end1 - end2).magnitude < 1:
                    common = end1
                    dir1 = (start1 - end1).normalize()
                    dir2 = (start2 - end2).normalize()
                
                if common:
                    # Calculate angle
                    angle = math.degrees(math.acos(
                        max(-1, min(1, dir1.dot(dir2)))
                    ))
                    
                    if angle > 5:  # Skip very small angles
                        # Add angular dimension
                        p1 = common + dir1 * 30
                        p2 = common + dir2 * 30
                        
                        dim = msp.add_angular_dim(
                            base=common,
                            p1=p1,
                            p2=p2,
                            location=common + (dir1 + dir2).normalize() * 40,
                            dimstyle=dim_style
                        )
                        
                        dim.set_text(f"{angle:.1f}° ±{tolerance}°")
                        dim.render()
    
    def add_geometric_tolerances(self, msp, entities: List[CADEntity]) -> None:
        """
        Add geometric tolerance symbols (GD&T)
        
        Args:
            msp: Modelspace
            entities: CAD entities
        """
        # Find circles for circularity tolerance
        circles = [e for e in entities if e.entity_type == 'CIRCLE']
        
        for i, circle in enumerate(circles[:3]):  # Limit to first 3
            p = circle.properties
            center = Vec2(p['center'][0], p['center'][1])
            radius = p['radius']
            
            # Position for tolerance frame
            pos = center + Vec2(radius + 30, i * 15)
            
            # Draw tolerance frame
            self._draw_tolerance_frame(
                msp, pos,
                symbol="○",  # Circularity
                tolerance=0.05,
                datum="A"
            )
    
    def _draw_tolerance_frame(self, msp, pos: Vec2, symbol: str,
                             tolerance: float, datum: str) -> None:
        """Draw GD&T tolerance frame"""
        frame_width = 25
        frame_height = 10
        
        # Draw frame
        msp.add_lwpolyline(
            points=[
                (pos.x, pos.y),
                (pos.x + frame_width, pos.y),
                (pos.x + frame_width, pos.y + frame_height),
                (pos.x, pos.y + frame_height)
            ],
            close=True,
            dxfattribs={'color': 7}
        )
        
        # Add symbol
        msp.add_text(
            symbol,
            height=4,
            dxfattribs={'insert': (pos.x + 2, pos.y + 3)}
        )
        
        # Add tolerance value
        msp.add_text(
            f"⌀{tolerance}",
            height=4,
            dxfattribs={'insert': (pos.x + 10, pos.y + 3)}
        )
        
        # Add datum
        msp.add_text(
            datum,
            height=4,
            dxfattribs={'insert': (pos.x + 20, pos.y + 3)}
        )
    
    def add_surface_roughness(self, msp, entities: List[CADEntity]) -> None:
        """
        Add surface roughness symbols
        
        Args:
            msp: Modelspace
            entities: CAD entities
        """
        lines = [e for e in entities if e.entity_type == 'LINE']
        
        for i, line in enumerate(lines[:5]):  # First 5 lines
            p = line.properties
            start = Vec2(p['start'][0], p['start'][1])
            end = Vec2(p['end'][0], p['end'][1])
            mid = (start + end) * 0.5
            
            # Position symbol
            pos = mid + Vec2(0, 15)
            
            # Draw roughness symbol (check mark shape)
            size = 5
            msp.add_line((pos.x, pos.y), (pos.x + size, pos.y + size),
                        dxfattribs={'color': 7})
            msp.add_line((pos.x + size, pos.y + size), (pos.x + size * 2, pos.y),
                        dxfattribs={'color': 7})
            msp.add_line((pos.x + size * 0.5, pos.y + size * 0.5),
                        (pos.x + size * 1.5, pos.y + size * 0.5),
                        dxfattribs={'color': 7})
            
            # Add Ra value
            msp.add_text(
                "Ra 3.2",
                height=2.5,
                dxfattribs={'insert': (pos.x, pos.y + size + 2)}
            )
    
    def add_iso_tolerance_table(self, msp, x: float, y: float) -> None:
        """
        Add ISO tolerance grade table
        
        Args:
            msp: Modelspace
            x, y: Position
        """
        # Table header
        headers = ["Campo", "IT Grade", "Tolleranza"]
        data = [
            ("0-3", "IT7", "±0.01"),
            ("3-6", "IT8", "±0.014"),
            ("6-10", "IT9", "±0.025"),
            ("10-18", "IT10", "±0.04"),
            ("18-30", "IT11", "±0.06"),
        ]
        
        col_widths = [20, 20, 25]
        row_height = 6
        
        # Draw header
        x_pos = x
        for i, header in enumerate(headers):
            msp.add_text(
                header,
                height=2.5,
                dxfattribs={'insert': (x_pos + 2, y - 2)}
            )
            x_pos += col_widths[i]
        
        # Draw rows
        y_pos = y - row_height
        for row in data:
            x_pos = x
            for i, value in enumerate(row):
                msp.add_text(
                    value,
                    height=2,
                    dxfattribs={'insert': (x_pos + 2, y_pos - 2)}
                )
                x_pos += col_widths[i]
            y_pos -= row_height
    
    def add_material_list(self, msp, x: float, y: float) -> None:
        """
        Add bill of materials / material list
        
        Args:
            msp: Modelspace
            x, y: Position
        """
        title = "MATERIALE"
        msp.add_text(
            title,
            height=3,
            dxfattribs={'insert': (x, y), 'style': 'BOLD'}
        )
        
        materials = [
            "Materiale: Acciaio S235JR",
            "Trattamento: Nessuno",
            "Finitura: Verniciatura",
            "Peso: ~0.5 kg"
        ]
        
        y_pos = y - 8
        for material in materials:
            msp.add_text(
                material,
                height=2.5,
                dxfattribs={'insert': (x, y_pos)}
            )
            y_pos -= 5
    
    def add_projection_views(self, msp, entities: List[CADEntity],
                            bbox: Tuple[float, float, float, float]) -> None:
        """
        Add first-angle projection views (European standard)
        
        Args:
            msp: Modelspace
            entities: CAD entities
            bbox: Bounding box (minx, miny, maxx, maxy)
        """
        minx, miny, maxx, maxy = bbox
        width = maxx - minx
        height = maxy - miny
        
        # View spacing
        spacing = max(width, height) + 50
        
        # Front view (original position)
        # Top view (above front)
        # Right view (to the right of front)
        
        # Copy entities for top view (mirrored Y)
        for entity in entities[:10]:  # Limit for performance
            if entity.entity_type == 'LINE':
                p = entity.properties
                start = (p['start'][0], maxy + spacing - (p['start'][1] - miny))
                end = (p['end'][0], maxy + spacing - (p['end'][1] - miny))
                msp.add_line(start, end, dxfattribs={'color': 5, 'linetype': 'DASHED'})
    
    def add_center_marks(self, msp, entities: List[CADEntity]) -> None:
        """
        Add center marks for circles and arcs
        
        Args:
            msp: Modelspace
            entities: CAD entities
        """
        circles_and_arcs = [e for e in entities 
                           if e.entity_type in ('CIRCLE', 'ARC')]
        
        for entity in circles_and_arcs:
            p = entity.properties
            center = Vec2(p['center'][0], p['center'][1])
            
            if entity.entity_type == 'CIRCLE':
                radius = p['radius']
            else:
                radius = p['radius']
            
            # Draw cross at center
            mark_size = min(radius * 0.3, 10)
            
            # Horizontal line
            msp.add_line(
                (center.x - mark_size, center.y),
                (center.x + mark_size, center.y),
                dxfattribs={'color': 4, 'linetype': 'CENTER'}
            )
            
            # Vertical line
            msp.add_line(
                (center.x, center.y - mark_size),
                (center.x, center.y + mark_size),
                dxfattribs={'color': 4, 'linetype': 'CENTER'}
            )
    
    def add_section_view_indicator(self, msp, pos: Vec2,
                                   direction: str = "A-A") -> None:
        """
        Add section view cutting plane indicator
        
        Args:
            msp: Modelspace
            pos: Position
            direction: Section identifier
        """
        # Draw cutting plane line
        msp.add_line(
            (pos.x - 30, pos.y),
            (pos.x + 30, pos.y),
            dxfattribs={'color': 1, 'linetype': 'PHANTOM', 'lineweight': 50}
        )
        
        # Add arrows
        arrow_size = 5
        # Left arrow
        msp.add_line((pos.x - 30, pos.y), (pos.x - 30 + arrow_size, pos.y + arrow_size),
                    dxfattribs={'color': 1})
        msp.add_line((pos.x - 30, pos.y), (pos.x - 30 + arrow_size, pos.y - arrow_size),
                    dxfattribs={'color': 1})
        
        # Right arrow
        msp.add_line((pos.x + 30, pos.y), (pos.x + 30 - arrow_size, pos.y + arrow_size),
                    dxfattribs={'color': 1})
        msp.add_line((pos.x + 30, pos.y), (pos.x + 30 - arrow_size, pos.y - arrow_size),
                    dxfattribs={'color': 1})
        
        # Add label
        msp.add_text(
            direction,
            height=4,
            dxfattribs={'insert': (pos.x - 8, pos.y + 10), 'color': 1}
        )
    
    def add_weld_symbols(self, msp, entities: List[CADEntity]) -> None:
        """
        Add welding symbols to connected lines
        
        Args:
            msp: Modelspace
            entities: CAD entities
        """
        lines = [e for e in entities if e.entity_type == 'LINE']
        
        for i, line in enumerate(lines[:3]):
            p = line.properties
            start = Vec2(p['start'][0], p['start'][1])
            end = Vec2(p['end'][0], p['end'][1])
            mid = (start + end) * 0.5
            
            # Draw weld symbol (triangle)
            size = 4
            msp.add_lwpolyline(
                points=[
                    (mid.x - size, mid.y - size),
                    (mid.x, mid.y + size),
                    (mid.x + size, mid.y - size)
                ],
                close=True,
                dxfattribs={'color': 7}
            )
            
            # Add weld type
            msp.add_text(
                "V",
                height=3,
                dxfattribs={'insert': (mid.x - 2, mid.y - 2)}
            )
