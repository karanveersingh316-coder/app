"""
Preprocessor Module
Image preprocessing, enhancement, and normalization for edge detection
"""

import cv2
import numpy as np
from typing import Tuple, Optional
import logging

logger = logging.getLogger(__name__)


class Preprocessor:
    """Preprocesses images for optimal edge detection"""
    
    def __init__(self):
        """Initialize preprocessor"""
        logger.info("Preprocessor initialized")
    
    def enhance_contrast(self, image: np.ndarray, clip_limit: float = 2.0, 
                         grid_size: Tuple[int, int] = (8, 8)) -> np.ndarray:
        """
        Enhance image contrast using CLAHE (Contrast Limited Adaptive Histogram Equalization)
        
        Args:
            image: Input grayscale image
            clip_limit: Threshold for contrast limiting
            grid_size: Size of grid for histogram equalization
            
        Returns:
            Contrast enhanced image
        """
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
        enhanced = clahe.apply(image)
        logger.debug(f"Contrast enhanced with CLAHE")
        return enhanced
    
    def denoise(self, image: np.ndarray, strength: int = 10) -> np.ndarray:
        """
        Remove noise from image while preserving edges
        
        Args:
            image: Input image
            strength: Denoising strength
            
        Returns:
            Denoised image
        """
        if len(image.shape) == 3:
            denoised = cv2.fastNlMeansDenoisingColored(image, None, strength, strength, 7, 21)
        else:
            denoised = cv2.fastNlMeansDenoising(image, None, strength, 7, 21)
        
        logger.debug(f"Image denoised")
        return denoised
    
    def sharpen(self, image: np.ndarray) -> np.ndarray:
        """
        Sharpen image to enhance edges
        
        Args:
            image: Input image
            
        Returns:
            Sharpened image
        """
        # Create sharpening kernel
        kernel = np.array([[-1, -1, -1],
                          [-1,  9, -1],
                          [-1, -1, -1]])
        
        sharpened = cv2.filter2D(image, -1, kernel)
        logger.debug(f"Image sharpened")
        return sharpened
    
    def auto_canny(self, image: np.ndarray, sigma: float = 0.33) -> np.ndarray:
        """
        Automatic Canny edge detection with computed thresholds
        
        Args:
            image: Input grayscale image
            sigma: Standard deviation for threshold calculation
            
        Returns:
            Binary edge map
        """
        # Compute median
        median = np.median(image)
        
        # Calculate thresholds
        lower = int(max(0, (1.0 - sigma) * median))
        upper = int(min(255, (1.0 + sigma) * median))
        
        edges = cv2.Canny(image, lower, upper)
        logger.debug(f"Canny edges detected with thresholds: {lower}, {upper}")
        return edges
    
    def bilateral_filter(self, image: np.ndarray, d: int = 9, 
                         sigma_color: float = 75, sigma_space: float = 75) -> np.ndarray:
        """
        Apply bilateral filter to smooth while preserving edges
        
        Args:
            image: Input image
            d: Diameter of pixel neighborhood
            sigma_color: Filter sigma in color space
            sigma_space: Filter sigma in coordinate space
            
        Returns:
            Filtered image
        """
        filtered = cv2.bilateralFilter(image, d, sigma_color, sigma_space)
        logger.debug(f"Bilateral filter applied")
        return filtered
    
    def gamma_correction(self, image: np.ndarray, gamma: float = 1.0) -> np.ndarray:
        """
        Apply gamma correction
        
        Args:
            image: Input image
            gamma: Gamma value (< 1 darkens, > 1 brightens)
            
        Returns:
            Gamma corrected image
        """
        # Build lookup table
        inv_gamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in range(256)]).astype("uint8")
        
        corrected = cv2.LUT(image, table)
        logger.debug(f"Gamma correction applied: {gamma}")
        return corrected
    
    def preprocess_pipeline(self, image: np.ndarray, 
                           use_ai: bool = True) -> Tuple[np.ndarray, np.ndarray]:
        """
        Full preprocessing pipeline
        
        Args:
            image: Input image (BGR from OpenCV)
            use_ai: Whether AI model will be used (affects preprocessing)
            
        Returns:
            Tuple of (processed_image, edge_map)
        """
        logger.info("Starting preprocessing pipeline")
        
        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Step 1: Denoise
        denoised = self.denoise(gray, strength=5)
        
        # Step 2: Enhance contrast
        enhanced = self.enhance_contrast(denoised)
        
        # Step 3: Bilateral filter for edge preservation
        filtered = self.bilateral_filter(enhanced)
        
        # Step 4: Sharpen
        sharpened = self.sharpen(filtered)
        
        # Step 5: Edge detection (traditional)
        edges = self.auto_canny(sharpened)
        
        logger.info("Preprocessing pipeline completed")
        return sharpened, edges
    
    def binarize(self, image: np.ndarray, method: str = 'otsu') -> np.ndarray:
        """
        Binarize image
        
        Args:
            image: Input grayscale image
            method: 'otsu' or 'adaptive'
            
        Returns:
            Binary image
        """
        if method == 'otsu':
            _, binary = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        elif method == 'adaptive':
            binary = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                           cv2.THRESH_BINARY, 11, 2)
        else:
            raise ValueError(f"Unknown binarization method: {method}")
        
        logger.debug(f"Image binarized using {method}")
        return binary
    
    def skeletonize(self, image: np.ndarray) -> np.ndarray:
        """
        Skeletonize binary image (thinning)
        
        Args:
            image: Binary image
            
        Returns:
            Skeletonized image
        """
        from skimage.morphology import skeletonize as sk_skeletonize
        
        # Ensure binary
        binary = image > 0 if image.max() <= 1 else image > 127
        
        # Skeletonize
        skeleton = sk_skeletonize(binary)
        
        # Convert back to uint8
        result = (skeleton * 255).astype(np.uint8)
        
        logger.debug("Image skeletonized")
        return result
