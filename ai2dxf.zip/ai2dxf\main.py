"""
AI2DXF - Main Entry Point
AI-powered Image to CAD Converter

Usage:
    python main.py                    # Launch GUI
    python main.py --image <path>     # Process single image
    python main.py --batch <folder>   # Batch process folder
"""

import sys
import argparse
import logging
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.image_loader import ImageLoader
from src.preprocessor import Preprocessor
from src.ai_model import EdgeDetectionAI
from src.geometry_extractor import GeometryExtractor
from src.vectorizer import Vectorizer
from src.dxf_generator import DXFGenerator
from src.pdf_generator import PDFGenerator


def setup_logging(verbose: bool = False):
    """Setup logging configuration"""
    level = logging.DEBUG if verbose else logging.INFO
    
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )


def process_image(image_path: str, output_path: str, params: dict = None) -> bool:
    """
    Process a single image
    
    Args:
        image_path: Path to input image
        output_path: Path for output DXF or PDF
        params: Processing parameters
        
    Returns:
        True if successful
    """
    logger = logging.getLogger(__name__)
    logger.info(f"Processing: {image_path}")
    
    params = params or {}
    output_format = params.get('format', 'dxf').lower()
    
    try:
        # Initialize components
        loader = ImageLoader(max_dim=params.get('max_dim', 2048))
        preprocessor = Preprocessor()
        ai_model = EdgeDetectionAI(model_path=params.get('model_path'))
        extractor = GeometryExtractor(
            line_threshold=params.get('line_threshold', 100),
            min_line_length=params.get('min_line_length', 50)
        )
        vectorizer = Vectorizer()
        
        # Load image
        logger.info("Loading image...")
        image = loader.load(image_path)
        if image is None:
            logger.error("Failed to load image")
            return False
        
        # Preprocess
        logger.info("Preprocessing...")
        processed, edges = preprocessor.preprocess_pipeline(image)
        
        # Edge detection
        logger.info("Detecting edges...")
        edge_map = ai_model.detect_edges(processed)
        
        # Extract geometry
        logger.info("Extracting geometry...")
        primitives = extractor.extract_all(edge_map)
        
        if len(primitives) == 0:
            logger.warning("No geometry detected!")
            return False
        
        logger.info(f"Detected {len(primitives)} primitives")
        
        # Vectorize
        logger.info("Vectorizing...")
        entities = vectorizer.vectorize(primitives)
        entities = vectorizer.optimize_entities(entities)
        
        # Generate output based on format
        if output_format == 'pdf':
            logger.info("Generating PDF...")
            pdf_gen = PDFGenerator()
            success = pdf_gen.create_pdf(entities, output_path)
            if success:
                stats = pdf_gen.get_statistics(entities)
                logger.info(f"PDF saved: {output_path}")
                logger.info(f"Statistics: {stats}")
        else:
            logger.info("Generating DXF...")
            dxf_gen = DXFGenerator()
            success = dxf_gen.create_dxf(entities, output_path)
            if success:
                stats = dxf_gen.get_entity_statistics(entities)
                logger.info(f"DXF saved: {output_path}")
                logger.info(f"Statistics: {stats}")
        
        return success
        
    except Exception as e:
        logger.error(f"Processing failed: {e}")
        return False


def batch_process(input_folder: str, output_folder: str, params: dict = None):
    """
    Batch process all images in a folder
    
    Args:
        input_folder: Folder containing images
        output_folder: Folder for output DXF files
        params: Processing parameters
    """
    logger = logging.getLogger(__name__)
    
    input_path = Path(input_folder)
    output_path = Path(output_folder)
    
    # Create output folder if needed
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Find all images
    extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff']
    images = []
    for ext in extensions:
        images.extend(input_path.glob(ext))
        images.extend(input_path.glob(ext.upper()))
    
    logger.info(f"Found {len(images)} images to process")
    
    # Process each image
    success_count = 0
    for img_path in images:
        output_file = output_path / f"{img_path.stem}.dxf"
        
        if process_image(str(img_path), str(output_file), params):
            success_count += 1
    
    logger.info(f"Batch complete: {success_count}/{len(images)} successful")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='AI2DXF - Convert images to CAD drawings',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                          # Launch GUI
  python main.py -i image.jpg -o out.dxf  # Process single image
  python main.py -b ./images -o ./output  # Batch process folder
        """
    )
    
    parser.add_argument('-i', '--image', 
                       help='Input image path')
    parser.add_argument('-o', '--output', 
                       default='output.pdf',
                       help='Output file path (default: output.pdf)')
    parser.add_argument('-f', '--format', 
                       choices=['pdf', 'dxf'], default='pdf',
                       help='Output format: pdf or dxf (default: pdf)')
    parser.add_argument('-b', '--batch',
                       help='Batch process folder')
    parser.add_argument('--model',
                       help='Path to ONNX model (optional)')
    parser.add_argument('--max-dim', type=int, default=2048,
                       help='Maximum image dimension (default: 2048)')
    parser.add_argument('--line-threshold', type=int, default=100,
                       help='Line detection threshold (default: 100)')
    parser.add_argument('--min-line-length', type=int, default=50,
                       help='Minimum line length (default: 50)')
    parser.add_argument('-v', '--verbose', action='store_true',
                       help='Enable verbose logging')
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.verbose)
    
    # Collect parameters
    params = {
        'max_dim': args.max_dim,
        'line_threshold': args.line_threshold,
        'min_line_length': args.min_line_length,
        'model_path': args.model,
        'format': args.format
    }
    
    # Launch appropriate mode
    if args.batch:
        # Batch mode
        batch_process(args.batch, args.output, params)
        
    elif args.image:
        # Single image mode
        success = process_image(args.image, args.output, params)
        sys.exit(0 if success else 1)
        
    else:
        # GUI mode
        try:
            from src.ui import main as gui_main
            gui_main()
        except ImportError as e:
            print(f"GUI not available: {e}")
            print("Use -i/--image to process from command line")
            sys.exit(1)


if __name__ == "__main__":
    main()
