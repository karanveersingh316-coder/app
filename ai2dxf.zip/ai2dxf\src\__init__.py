"""
AI2DXF - AI-powered Image to CAD Converter

A desktop application that converts real images into technical CAD drawings (DXF format)
using computer vision and edge detection AI - completely offline.

Modules:
    image_loader: Image loading and preprocessing
    ai_model: Edge detection using ONNX models
    preprocessor: Image normalization and enhancement
    geometry_extractor: Shape detection (lines, circles, arcs)
    vectorizer: Convert pixels to geometric primitives
    dxf_generator: CAD file export
    ui: Desktop interface (PyQt6)
"""

__version__ = "1.0.0"
__author__ = "AI2DXF Project"
